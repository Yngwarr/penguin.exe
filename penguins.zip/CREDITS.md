* 98.css for Windows 98-esque interface;
* Win95.css for progress bar style;
* Windows93.net for some ideas on implementation;
* jgs (via windows93.net) for ASCII-art in the beginning;
