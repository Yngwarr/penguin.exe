* 98.css for Windows 98-esque interface;
* Win95.css for progress bar style;
* Windows93.net for some ideas on implementation;
* jgs (via windows93.net) for ASCII-art in the beginning;
* https://retroindiejosh.itch.io/music-pack-13
* https://freesound.org/people/Perel/sounds/173440/
* https://freesound.org/people/Princess6537/sounds/144885/
* https://freesound.org/people/THE_bizniss/sounds/39562/
* https://freesound.org/people/Breviceps/sounds/564237/
* https://freesound.org/people/guitarguy1985/sounds/52050/
